# urlToHTML
Save your favorite site, blog, html in just two lines of code. 


This is an example project that is used to demonstrate how to publish Python packages on PyPI. To take a look at the step by step guide on how to do so, make sure you read my article on Towards Data Science.
